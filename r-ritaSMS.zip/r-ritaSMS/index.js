const express = require("express");
const functions = require('firebase-functions')



const admin = require("firebase-admin");

const app = express()

const fs = require("fs");
  
// Parsing the form of body to take
// input from forms
const bodyParser = require("body-parser");
  
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
  




const serviceAccount = require("./r-rita-2abda-firebase-adminsdk-rs03e-b35dc10215.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://r-rita-2abda-default-rtdb.firebaseio.com/",
  
});

//const db = admin.firestore();

//admin.initializeApp(functions.config().firebase);

const port = 3000;

  //..........................post................................



  app.post("/", function (req, res) {
    res.contentType ('text/plain');
  

var sms = req.body.text;


    var db = admin.database();
    var ref = db.ref("/refugeeDetails");
    
    
    ref.on("value", function(snapshot) {
     // console.log(snapshot.val());
    
      var students =[];
        snapshot.forEach(childsnapshot=>{
          students.push(snapshot.val())
        })
      
        //console.log(JSON.stringify(students));
    
        var stud =students[1]
        var reply = [];
        var agent = [];
        var name = [];
    
        var result = [];
    
    for(var i in stud)
        result.push([i, stud [i]]);
    
        //console.log(JSON.stringify(result));
    
        for (let i = 0; i < result.length; i++) {
            result[i][1]
    
            //console.log(JSON.stringify(result[i][1].name +" " +result[i][1].age +" " + result[i][1].code +" " + result[i][1].desc));
            //console.log(JSON.stringify(result[i][1].age));
    
            var vfname= result[i][1].fname.replace(/^"(.+(?="$))"$/, '$1');
            var vsname= result[i][1].sname.replace(/^"(.+(?="$))"$/, '$1');
            var vage= result[i][1].age.replace(/^"(.+(?="$))"$/, '$1');
            var vcountry= result[i][1].country.replace(/^"(.+(?="$))"$/, '$1');
            var vcamp= result[i][1].camp.replace(/^"(.+(?="$))"$/, '$1');
            var vlang= result[i][1].lang.replace(/^"(.+(?="$))"$/, '$1');
            var vrelief= result[i][1].relief.replace(/^"(.+(?="$))"$/, '$1');
            var vcode= result[i][1].code.replace(/^"(.+(?="$))"$/, '$1');
            var vagent= result[i][1].agent.replace(/^"(.+(?="$))"$/, '$1');
    

            // }
          //........................
    
    
        
        //op =JSON.stringify(result[1][1].name)
        
       //var po= op.replace(/^"(.+(?="$))"$/, '$1');
    
      // var sms = req.body.text;
   //var sms="rf539";
    //-----------save................................................................
   
    if(vcode==sms){
    
    var ref2 = db.ref("received/"+vcode);
        ref2.set({
       
          "fname": vfname,
          "sname": vsname,
          "age": vage,
          "country": vcountry,
          "camp": vcamp,
          "lang": vlang,
          "code": vcode,
          "relief": vrelief,
          "agent":vagent,
           
             });  
    
             //res.send("successfull"+sms);

             reply.push(vrelief);

             agent.push(vagent);

             name.push(vsname);
    
            }
    
      
          

        } 
    //...............closed.............................   


    if (reply.length ==0) {

      
      
      
      res.send("invalid input");
      }

      else{
        
        res.send("Dear"+" " +name[0]+" "+ "you have approved a receipt of "+ " " + reply[0]+" "+"delivered by"+" "+ agent[0]);
      
      }
    
    });





  });
    






 

// collection ref


  //..............................




  app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
  })